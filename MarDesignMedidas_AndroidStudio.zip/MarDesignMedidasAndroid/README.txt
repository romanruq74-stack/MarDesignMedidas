MAR DESIGN - MEDIDAS

Proyecto Android listo para abrir en Android Studio y generar el APK.

1. Abre esta carpeta en Android Studio.
2. Espera a que Gradle sincronice.
3. Build > Build APK(s).
4. El APK aparecerá en app/build/outputs/apk/debug/app-debug.apk

La aplicación contiene la versión HTML de Mar Design - Medidas dentro de assets y funciona sin conexión para guardar los datos en el almacenamiento local del teléfono.
